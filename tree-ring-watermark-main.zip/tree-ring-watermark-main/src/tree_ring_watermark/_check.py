from diffusers import DiffusionPipeline

def check(pipeline: DiffusionPipeline, model_hash: str):
    pass
