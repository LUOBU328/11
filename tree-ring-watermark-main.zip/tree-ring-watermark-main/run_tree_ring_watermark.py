# --- run_tree_ring_watermark.py (Complete Final Code - Reverted pipe call) ---

import argparse
import wandb
import copy
from tqdm import tqdm
from statistics import mean, stdev
import os
import torch
import sys # Import sys for exiting
import traceback # Import traceback for detailed error printing

# --- Library Imports ---
# Core libraries needed by the script
from inverse_stable_diffusion import InversableStableDiffusionPipeline
from diffusers import DPMSolverMultistepScheduler
import open_clip
from optim_utils import * # Assumes this contains necessary functions like set_random_seed, etc.
from io_utils import * # Assumes this contains transform_img, etc.

# Imports needed specifically for the modified get_dataset
from datasets import load_dataset, Dataset # Import Dataset class
try:
    import pandas as pd # Required for local file loading now
except ImportError:
    print("Error: pandas library is required to load local parquet/csv files in this script.")
    print("Please install it using: pip install pandas pyarrow")
    sys.exit(1) # Exit if pandas not found
try:
    # Check if pyarrow is installed, needed for parquet
    import pyarrow
except ImportError:
    # Don't exit immediately, maybe user provides CSV
    print("Warning: pyarrow library not found. Loading local .parquet files will fail.")
    print("Install using: pip install pyarrow")

# Import for evaluation metrics (conditionally imported later as well)
try:
    from sklearn import metrics
except ImportError:
    print("Warning: scikit-learn not found. Final metrics calculation (AUC, ACC) will be skipped.")
    metrics = None
try:
    import numpy as np
except ImportError:
    print("Warning: numpy not found. Final metrics calculation might fail or be skipped.")
    np = None
# --- End Library Imports ---


# --- Final Modified get_dataset function (Uses Pandas for local files) ---
def get_dataset(args):
    """Loads dataset based on args.dataset"""
    dataset_name = args.dataset
    prompt_key = None # Default to None, must be set

    # --- START MODIFICATION ---
    if os.path.exists(dataset_name) and dataset_name.endswith('.parquet'):
        print(f"Loading local parquet dataset using pandas: {dataset_name}")
        try:
            # Check pyarrow again, exit if not found and trying to load parquet
            import pyarrow
            # --- Use pandas to read parquet ---
            df = pd.read_parquet(dataset_name)
            print(f"  Successfully read parquet file. Columns: {df.columns.tolist()}")

            # --- Convert pandas DataFrame to datasets.Dataset ---
            dataset = Dataset.from_pandas(df)
            print(f"  Converted pandas DataFrame to datasets.Dataset. Num rows: {len(dataset)}")

            # !!! CRITICAL: Based on your output, 'Prompt' is correct !!!
            if 'Prompt' in df.columns:
                prompt_key = 'Prompt' # <-- Confirmed from your check
            else:
                 print(f"Error: Expected column 'Prompt' not found in {dataset_name}. Found columns: {df.columns.tolist()}")
                 sys.exit(1)

        except ImportError:
             print("\nError: Loading parquet files requires the 'pyarrow' library.")
             print("Please install it using: pip install pyarrow")
             sys.exit(1) # Exit the script
        except Exception as e:
             print(f"\nError processing local parquet file {dataset_name} with pandas: {e}")
             print("Check if the file exists, is a valid parquet file, and pandas/pyarrow are installed correctly.")
             traceback.print_exc()
             sys.exit(1) # Exit the script

    elif os.path.exists(dataset_name) and dataset_name.endswith('.csv'):
         print(f"Loading local csv dataset using pandas: {dataset_name}")
         try:
             # --- Use pandas to read CSV ---
             df = pd.read_csv(dataset_name)
             print(f"  Successfully read CSV file. Columns: {df.columns.tolist()}")
             # --- Convert pandas DataFrame to datasets.Dataset ---
             dataset = Dataset.from_pandas(df)
             print(f"  Converted pandas DataFrame to datasets.Dataset. Num rows: {len(dataset)}")

             # !!! CRITICAL: Find the correct column name for CSV if you use one !!!
             # Check the CSV header row to find the column name
             # Example check:
             if 'Prompt' in df.columns: # You MUST verify this for your CSV
                 prompt_key = 'Prompt'
             elif 'prompt' in df.columns:
                 prompt_key = 'prompt'
             elif 'text' in df.columns:
                 prompt_key = 'text'
             # Add more checks or manual setting if needed
             else:
                 print(f"Error: Could not automatically determine prompt column in CSV {dataset_name}. Found columns: {df.columns.tolist()}")
                 print("Please update the prompt_key logic in get_dataset for CSV handling.")
                 sys.exit(1)
             print(f"Using prompt key '{prompt_key}' for CSV.")


         except Exception as e:
             print(f"\nError processing local CSV file {dataset_name} with pandas: {e}")
             print("Check if the file exists and is a valid CSV file, and pandas is installed correctly.")
             traceback.print_exc()
             sys.exit(1) # Exit the script
    else:
         # Original logic for loading from Hugging Face Hub (Keep this)
         print(f"Loading dataset from Hub: {dataset_name}")
         try:
             dataset_dict = load_dataset(dataset_name, cache_dir=os.getenv('HF_HOME')) # Added cache_dir
             if 'train' in dataset_dict:
                 dataset = dataset_dict['train']
             else:
                 first_split = next(iter(dataset_dict))
                 print(f"Warning: 'train' split not found in Hub dataset. Using first available split: '{first_split}'")
                 dataset = dataset_dict[first_split]

             column_names = dataset.column_names
             if 'prompt' in column_names: prompt_key = 'prompt'
             elif 'text' in column_names: prompt_key = 'text'
             elif 'caption' in column_names: prompt_key = 'caption'
             elif 'Prompt' in column_names: prompt_key = 'Prompt' # Check case too
             else:
                 print(f"Warning: Could not automatically determine prompt key for Hub dataset {dataset_name}.")
                 if len(column_names) == 1:
                      prompt_key = column_names[0]
                      print(f"Using the only column found as prompt key: '{prompt_key}'")
                 else:
                      print(f"Available columns: {column_names}. Attempting to use first column: '{column_names[0]}'")
                      prompt_key = column_names[0]

         except Exception as e:
             print(f"\nError loading dataset '{dataset_name}' from Hub: {e}")
             print("Please check the dataset path/name and ensure you have internet access.")
             traceback.print_exc()
             sys.exit(1)
    # --- END MODIFICATION ---

    if prompt_key is None:
         print(f"\nError: Could not determine the prompt key for dataset {dataset_name}")
         sys.exit(1)
    # Verify the key exists in the final dataset object
    if prompt_key not in dataset.column_names:
         print(f"\nInternal Error: Determined prompt key '{prompt_key}' not found in the final dataset columns: {dataset.column_names}")
         sys.exit(1)

    print(f"Using prompt key: '{prompt_key}'")
    return dataset, prompt_key
# --- End Final Modified get_dataset function ---


def main(args):
    table = None
    if args.with_tracking:
        try:
            wandb.init(project='diffusion_watermark', name=args.run_name,
                       tags=['tree_ring_watermark_generation'])
            wandb.config.update(args)
            table = wandb.Table(
                columns=['gen_no_w', 'no_w_clip_score', 'gen_w', 'w_clip_score', 'prompt', 'no_w_metric', 'w_metric'])
        except Exception as e:
            print(f"Wandb initialization failed: {e}. Tracking disabled.")
            args.with_tracking = False

    # load diffusion model
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")

    cache_dir_main = os.getenv('HF_HOME')
    if cache_dir_main:
         print(f"Using cache directory: {cache_dir_main}")
    else:
         print("Warning: HF_HOME environment variable not set. Using default huggingface cache directory.")

    try:
        model_dtype = torch.float16 if device == 'cuda' else torch.float32

        scheduler = DPMSolverMultistepScheduler.from_pretrained(
            args.model_id,
            subfolder='scheduler',
            cache_dir=cache_dir_main
        )
        pipe = InversableStableDiffusionPipeline.from_pretrained(
            args.model_id,
            scheduler=scheduler,
            torch_dtype=model_dtype,
            revision='fp16' if device == 'cuda' else None,
            safety_checker=None,
            cache_dir=cache_dir_main,
        )

        print(f"Moving model components to {device} with dtype {model_dtype}...")
        pipe.vae.to(device=device, dtype=model_dtype)
        pipe.text_encoder.to(device=device, dtype=model_dtype)
        pipe.unet.to(device=device, dtype=model_dtype)

        print("Diffusion pipeline loaded successfully.")
    except Exception as e:
        print(f"Error loading diffusion pipeline: {e}")
        print("Please check the model ID, internet access (or cache), and dependencies.")
        traceback.print_exc()
        return

    # reference model
    ref_model = None
    ref_clip_preprocess = None
    ref_tokenizer = None
    if args.reference_model is not None:
        try:
            print(f"Loading reference model: {args.reference_model}")
            ref_model, _, ref_clip_preprocess = open_clip.create_model_and_transforms(
                args.reference_model,
                pretrained=args.reference_model_pretrain,
                device=device,
                cache_dir=cache_dir_main
            )
            ref_tokenizer = open_clip.get_tokenizer(args.reference_model)
            if ref_model is not None:
                 ref_model.to(device)
            print("Reference model loaded.")
        except Exception as e:
            print(f"Could not load reference model: {e}. CLIP scores will be 0.")
            args.reference_model = None

    # dataset
    try:
        dataset, prompt_key = get_dataset(args) # Call the modified function
        print(f"Dataset loaded successfully. Number of samples available: {len(dataset)}")
        if args.end > len(dataset):
             print(f"Warning: --end index ({args.end}) > dataset size ({len(dataset)}). Adjusting --end to {len(dataset)}.")
             args.end = len(dataset)
        if args.start >= args.end:
             print(f"Error: --start index ({args.start}) must be less than --end index ({args.end}). Exiting.")
             return
        print(f"Will process prompts from index {args.start} to {args.end - 1}.")
    except Exception as e:
        print(f"Error during dataset processing stage: {e}")
        traceback.print_exc()
        return

    # tester prompt embeddings (still needed for reverse diffusion)
    tester_prompt = ''
    try:
        uncond_tokens = pipe.tokenizer(tester_prompt, padding="max_length", max_length=pipe.tokenizer.model_max_length, truncation=True, return_tensors="pt").input_ids.to(device)
        # Ensure uncond_embeddings are the correct dtype for the model
        uncond_embeddings = pipe.text_encoder(uncond_tokens)[0].to(device=device, dtype=model_dtype)
        print("Tester/unconditional text embeddings obtained.")
    except Exception as e:
        print(f"Error getting text embedding for tester prompt: {e}")
        traceback.print_exc()
        return

    # ground-truth patch
    try:
        gt_patch = get_watermarking_pattern(pipe, args, device)
        print("Watermarking pattern generated.")
    except Exception as e:
        print(f"Error getting watermarking pattern: {e}")
        traceback.print_exc()
        return

    results = []
    clip_scores = []
    clip_scores_w = []
    no_w_metrics = []
    w_metrics = []

    output_dir = 'generated_images'
    os.makedirs(output_dir, exist_ok=True)
    print(f"Generated images will be saved to: {os.path.abspath(output_dir)}")

    print(f"\nStarting generation loop from index {args.start} to {args.end - 1}...")
    for i in tqdm(range(args.start, args.end), desc="Generating Images"):
        seed = i + args.gen_seed

        try:
            current_prompt = dataset[i][prompt_key]
            print(f"\n[{i+1}/{args.end}] Seed: {seed}, Prompt: '{current_prompt[:100]}...'")
        except Exception as e:
            print(f"Error accessing dataset index {i} with key '{prompt_key}': {e}. Skipping.")
            continue

        # --- Removed pre-calculation of combined text embeddings ---

        # --- Generation without watermarking (using string prompt) ---
        try:
            set_random_seed(seed)
            init_latents_no_w = pipe.get_random_latents(height=args.image_length, width=args.image_length, generator=torch.Generator(device=device).manual_seed(seed))
            init_latents_no_w = init_latents_no_w.to(device=device, dtype=model_dtype)

            print("Generating non-watermarked image...")
            # --- MODIFIED CALL: Pass prompt string ---
            outputs_no_w = pipe(
                current_prompt, # Pass the prompt string directly
                num_images_per_prompt=args.num_images,
                guidance_scale=args.guidance_scale,
                num_inference_steps=args.num_inference_steps,
                height=args.image_length,
                width=args.image_length,
                latents=init_latents_no_w,
                output_type='pil',
                generator=torch.Generator(device=device).manual_seed(seed) # Pass generator for reproducibility
            )
            # --- END MODIFIED CALL ---
            orig_image_no_w = outputs_no_w.images[0]
            print("Non-watermarked image generated.")
        except Exception as e:
            print(f"Error during non-watermarked generation for prompt index {i}: {e}. Skipping.")
            traceback.print_exc()
            continue

        # --- Generation with watermarking (using string prompt) ---
        try:
            print("Preparing for watermarked generation...")
            init_latents_w = copy.deepcopy(init_latents_no_w).to(device=device, dtype=model_dtype)
            watermarking_mask = get_watermarking_mask(init_latents_w, args, device)
            init_latents_w = inject_watermark(init_latents_w, watermarking_mask, gt_patch, args)
            print("Watermark injected into latents.")

            print("Generating watermarked image...")
             # --- MODIFIED CALL: Pass prompt string ---
            outputs_w = pipe(
                current_prompt, # Pass the prompt string directly
                num_images_per_prompt=args.num_images,
                guidance_scale=args.guidance_scale,
                num_inference_steps=args.num_inference_steps,
                height=args.image_length,
                width=args.image_length,
                latents=init_latents_w, # Use watermarked latents
                output_type='pil',
                generator=torch.Generator(device=device).manual_seed(seed) # Pass generator
            )
            # --- END MODIFIED CALL ---
            orig_image_w = outputs_w.images[0]
            print("Watermarked image generated.")

            filename = f"watermarked_image_{i:04d}_seed{seed}.png"
            filepath = os.path.join(output_dir, filename)
            try:
                orig_image_w.save(filepath)
                print(f"Saved watermarked image to: {filepath}")
            except Exception as e:
                print(f"Error saving image {filepath}: {e}")

        except Exception as e:
            print(f"Error during watermarked generation or saving for prompt index {i}: {e}. Skipping evaluation.")
            traceback.print_exc()
            if args.with_tracking and table:
                table.add_data(None, 0, None, 0, current_prompt, 'Error', 'Error')
            continue

        # --- Evaluation Steps ---
        try:
            print("Starting evaluation steps...")
            orig_image_no_w_auged, orig_image_w_auged = image_distortion(orig_image_no_w, orig_image_w, seed, args)

            # Ensure image tensors have the correct dtype for the model
            img_no_w = transform_img(orig_image_no_w_auged).unsqueeze(0).to(device=device, dtype=model_dtype)
            image_latents_no_w = pipe.get_image_latents(img_no_w, sample=False)
            reversed_latents_no_w = pipe.forward_diffusion(
                latents=image_latents_no_w,
                text_embeddings=uncond_embeddings, # Use pre-calculated uncond embeds
                guidance_scale=1,
                num_inference_steps=args.test_num_inference_steps,
            )

            img_w = transform_img(orig_image_w_auged).unsqueeze(0).to(device=device, dtype=model_dtype)
            image_latents_w = pipe.get_image_latents(img_w, sample=False)
            reversed_latents_w = pipe.forward_diffusion(
                latents=image_latents_w,
                text_embeddings=uncond_embeddings, # Use pre-calculated uncond embeds
                guidance_scale=1,
                num_inference_steps=args.test_num_inference_steps,
            )

            no_w_metric, w_metric = eval_watermark(reversed_latents_no_w, reversed_latents_w, watermarking_mask,
                                                   gt_patch, args)
            print(f"Evaluation metrics: no_w={no_w_metric:.4f}, w={w_metric:.4f}")

            if args.reference_model is not None and ref_model is not None:
                print("Calculating CLIP scores...")
                sims = measure_similarity([orig_image_no_w, orig_image_w], current_prompt, ref_model,
                                          ref_clip_preprocess, ref_tokenizer, device)
                w_no_sim = sims[0].item()
                w_sim = sims[1].item()
                print(f"CLIP scores: no_w={w_no_sim:.4f}, w={w_sim:.4f}")
            else:
                w_no_sim, w_sim = 0, 0

            results.append({'no_w_metric': no_w_metric, 'w_metric': w_metric, 'w_no_sim': w_no_sim, 'w_sim': w_sim})
            no_w_metrics.append(-no_w_metric)
            w_metrics.append(-w_metric)
            clip_scores.append(w_no_sim)
            clip_scores_w.append(w_sim)

            if args.with_tracking and table and wandb.run:
                try:
                    log_image = (args.reference_model is not None) and (i < args.max_num_log_image)
                    table.add_data(wandb.Image(orig_image_no_w) if log_image else None,
                                   w_no_sim,
                                   wandb.Image(orig_image_w) if log_image else None,
                                   w_sim,
                                   current_prompt, no_w_metric, w_metric)
                except Exception as e_wandb:
                     print(f"Error logging data to wandb table: {e_wandb}")


        except Exception as e:
            print(f"Error during evaluation for index {i}: {e}. Skipping evaluation.")
            traceback.print_exc()
            if args.with_tracking and table and wandb.run:
                table.add_data(None, 0, None, 0, current_prompt, 'EvalError', 'EvalError')


    # --- Final evaluation summary ---
    print("\nGeneration loop finished. Calculating final metrics...")

    if np and metrics and len(no_w_metrics) > 0 and len(w_metrics) > 0:
        preds = no_w_metrics + w_metrics
        t_labels = [0] * len(no_w_metrics) + [1] * len(w_metrics)
        try:
            fpr, tpr, thresholds = metrics.roc_curve(t_labels, preds, pos_label=1)
            auc = metrics.auc(fpr, tpr)
            optimal_idx = np.argmax(tpr - fpr)
            acc = metrics.accuracy_score(t_labels, [1 if p >= thresholds[optimal_idx] else 0 for p in preds])
            low_fpr_indices = np.where(fpr <= 0.01)[0]
            low = tpr[low_fpr_indices[-1]] if len(low_fpr_indices) > 0 else 0.0
        except Exception as e:
             print(f"Error calculating ROC/AUC metrics: {e}")
             auc, acc, low = -1.0, -1.0, -1.0 # Indicate error

        if args.with_tracking and wandb.run: # Check wandb active
             try:
                 if table: wandb.log({'Table': table}) # Log table if it exists
                 wandb.log({'final/clip_score_mean': mean(clip_scores) if clip_scores else 0,
                            'final/clip_score_std': stdev(clip_scores) if len(clip_scores) > 1 else 0,
                            'final/w_clip_score_mean': mean(clip_scores_w) if clip_scores_w else 0,
                            'final/w_clip_score_std': stdev(clip_scores_w) if len(clip_scores_w) > 1 else 0,
                            'final/auc': auc,
                            'final/acc': acc,
                            'final/TPR@1%FPR': low})
             except Exception as e_wandb_final:
                  print(f"Error logging final metrics to wandb: {e_wandb_final}")

        print(f'\nFinal Metrics:')
        print(f'  CLIP Score Mean (no watermark): {mean(clip_scores):.4f}' if clip_scores else '  CLIP Score Mean (no watermark): N/A')
        print(f'  CLIP Score Mean (watermark):    {mean(clip_scores_w):.4f}' if clip_scores_w else '  CLIP Score Mean (watermark):    N/A')
        print(f'  Detection AUC: {auc:.4f}')
        print(f'  Detection ACC: {acc:.4f}')
        print(f'  Detection TPR@1%FPR: {low:.4f}')
    else:
        if not np: print("Skipping final metrics calculation: numpy not found.")
        if not metrics: print("Skipping final metrics calculation: scikit-learn not found.")
        if not (len(no_w_metrics) > 0 and len(w_metrics) > 0): print("Skipping final metrics calculation: Not enough evaluation results.")


    if args.with_tracking and wandb.run: # Check wandb active
        wandb.finish()
    print("\nScript finished.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='diffusion watermark generation')
    parser.add_argument('--run_name', default='generate_watermarked')
    parser.add_argument('--dataset', default='Gustavosta/Stable-Diffusion-Prompts',
                        help='Dataset path (Hub name or local file like .parquet/.csv)')
    parser.add_argument('--start', default=0, type=int, help='Starting index for prompts')
    parser.add_argument('--end', default=10, type=int, help='Ending index for prompts (exclusive)')
    parser.add_argument('--image_length', default=512, type=int)
    parser.add_argument('--model_id', default='stabilityai/stable-diffusion-2-1-base')
    parser.add_argument('--with_tracking', action='store_true', help='Enable WandB tracking')
    parser.add_argument('--num_images', default=1, type=int)
    parser.add_argument('--guidance_scale', default=7.5, type=float)
    parser.add_argument('--num_inference_steps', default=50, type=int)
    parser.add_argument('--test_num_inference_steps', default=None, type=int, help='Steps for reverse diffusion (eval only)')
    parser.add_argument('--reference_model', default=None, help='CLIP model for reference (e.g., ViT-B-32)')
    parser.add_argument('--reference_model_pretrain', default='laion2b_s34b_b79k', help='Pretraining dataset for ref model')
    parser.add_argument('--max_num_log_image', default=10, type=int)
    parser.add_argument('--gen_seed', default=0, type=int, help='Base seed offset')

    # watermark parameters
    parser.add_argument('--w_seed', default=999999, type=int)
    parser.add_argument('--w_channel', default=0, type=int)
    parser.add_argument('--w_pattern', default='rand')
    parser.add_argument('--w_mask_shape', default='circle')
    parser.add_argument('--w_radius', default=10, type=int)
    parser.add_argument('--w_measurement', default='l1_complex')
    parser.add_argument('--w_injection', default='complex')
    parser.add_argument('--w_pattern_const', default=0, type=float)

    # distortion parameters (only for evaluation)
    parser.add_argument('--r_degree', default=None, type=float)
    parser.add_argument('--jpeg_ratio', default=None, type=int)
    parser.add_argument('--crop_scale', default=None, type=float)
    parser.add_argument('--crop_ratio', default=None, type=float)
    parser.add_argument('--gaussian_blur_r', default=None, type=int)
    parser.add_argument('--gaussian_std', default=None, type=float)
    parser.add_argument('--brightness_factor', default=None, type=float)
    parser.add_argument('--rand_aug', default=0, type=int)

    args = parser.parse_args()

    if args.test_num_inference_steps is None:
        args.test_num_inference_steps = args.num_inference_steps

    if args.start < 0:
         print("Warning: --start index cannot be negative. Setting to 0.")
         args.start = 0
    if args.end <= args.start:
        print(f"Error: --end ({args.end}) must be greater than --start ({args.start}). Exiting.")
        sys.exit(1)

    if not os.getenv('HF_HOME'):
         print("Info: HF_HOME environment variable not set. Models/datasets might be cached in the default location.")

    # Check dependencies needed for local file loading BEFORE main()
    if (args.dataset.endswith('.parquet') or args.dataset.endswith('.csv')):
        if pd is None:
            print("Error: pandas library is required for loading local .parquet or .csv files.")
            print("Please install it using: pip install pandas")
            sys.exit(1)
    if args.dataset.endswith('.parquet'):
         try:
             import pyarrow
         except ImportError:
             print("Error: pyarrow library is required for loading local .parquet files.")
             print("Please install it using: pip install pyarrow")
             sys.exit(1)


    main(args)