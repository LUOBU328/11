"""
Codebase for "Improved Denoising Diffusion Probabilistic Models".
"""
