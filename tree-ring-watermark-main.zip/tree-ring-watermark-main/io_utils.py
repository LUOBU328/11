# --- run_tree_ring_watermark.py (Complete Modified Code) ---

import argparse
import wandb
import copy
from tqdm import tqdm
from statistics import mean, stdev
from sklearn import metrics
import os
import torch

# --- Added imports for dataset loading ---
from datasets import load_dataset
try:
    import pandas as pd # Optional: Needed only if using pandas to inspect columns
except ImportError:
    pd = None
# --- End Added imports ---


from inverse_stable_diffusion import InversableStableDiffusionPipeline
from diffusers import DPMSolverMultistepScheduler
import open_clip
from optim_utils import *
from io_utils import * # Keep this, even if get_dataset is moved here


# --- Moved and Modified get_dataset function ---
def get_dataset(args):
    """Loads dataset based on args.dataset"""
    dataset_name = args.dataset
    prompt_key = None # Default to None, must be set

    # --- START MODIFICATION ---
    if os.path.exists(dataset_name) and dataset_name.endswith('.parquet'):
        print(f"Loading local parquet dataset: {dataset_name}")
        # Make sure pyarrow is installed (pip install pyarrow)
        try:
            # Option 1: Directly load parquet using datasets library
            # Assuming the parquet file represents the 'train' split
            dataset = load_dataset('parquet', data_files={'train': dataset_name})['train']

            # !!! CRITICAL: Find the correct column name !!!
            # You MUST replace 'Prompt' with the actual column name containing the prompts
            # Use pandas to check:
            # df = pd.read_parquet(dataset_name)
            # print("Parquet columns:", df.columns)
            prompt_key = 'Prompt' # <--- !!! CHANGE THIS based on actual column name !!!

        except ImportError:
             print("\nError: Loading parquet files requires the 'pyarrow' library.")
             print("Please install it using: pip install pyarrow")
             exit()
        except Exception as e:
             print(f"\nError loading parquet file {dataset_name}: {e}")
             print("Check if the file exists and is a valid parquet file.")
             exit()

    elif os.path.exists(dataset_name) and dataset_name.endswith('.csv'):
         print(f"Loading local csv dataset: {dataset_name}")
         try:
             dataset = load_dataset('csv', data_files={'train': dataset_name})['train']
             # !!! CRITICAL: Find the correct column name for CSV !!!
             # Check the CSV header row to find the column name
             prompt_key = 'Prompt' # <--- !!! CHANGE THIS based on actual column name for CSV !!!
         except Exception as e:
             print(f"\nError loading CSV file {dataset_name}: {e}")
             print("Check if the file exists and is a valid CSV file.")
             exit()
    else:
         # Original logic for loading from Hugging Face Hub
         print(f"Loading dataset from Hub: {dataset_name}")
         try:
             # Attempt to load from Hub
             dataset_dict = load_dataset(dataset_name)
             # Try to find a 'train' split, otherwise use the first available split
             if 'train' in dataset_dict:
                 dataset = dataset_dict['train']
             else:
                 first_split = next(iter(dataset_dict))
                 print(f"Warning: 'train' split not found in Hub dataset. Using first available split: '{first_split}'")
                 dataset = dataset_dict[first_split]

             # Try common keys for Hub datasets, might need adjustment
             column_names = dataset.column_names
             if 'prompt' in column_names:
                 prompt_key = 'prompt'
             elif 'text' in column_names:
                 prompt_key = 'text'
             elif 'caption' in column_names:
                 prompt_key = 'caption'
             else:
                 # Fallback or raise error if key not found
                 print(f"Warning: Could not automatically determine prompt key for Hub dataset {dataset_name}.")
                 # Check if there's only one column, assume it's the prompt
                 if len(column_names) == 1:
                      prompt_key = column_names[0]
                      print(f"Using the only column found as prompt key: '{prompt_key}'")
                 else:
                      print(f"Available columns: {column_names}")
                      print("Please specify the correct prompt column name if loading fails.")
                      # As a last resort, maybe try the first column? Or exit?
                      prompt_key = column_names[0]
                      print(f"Attempting to use first column as prompt key: '{prompt_key}'")


         except Exception as e:
             print(f"\nError loading dataset '{dataset_name}' from Hub: {e}")
             print("Please check the dataset path/name and ensure you have internet access.")
             print("If it's a private dataset, ensure you are logged in (`huggingface-cli login`).")
             exit()
    # --- END MODIFICATION ---

    if prompt_key is None or prompt_key not in dataset.column_names:
         print(f"\nError: Determined prompt key '{prompt_key}' not found in the dataset columns: {dataset.column_names}")
         print("Please check the dataset or update the 'prompt_key' variable in the get_dataset function.")
         exit()

    print(f"Using prompt key: '{prompt_key}'")
    return dataset, prompt_key
# --- End Moved and Modified get_dataset function ---


def main(args):
    table = None
    if args.with_tracking:
        try:  # Add try-except for robustness if wandb is optional/fails
            wandb.init(project='diffusion_watermark', name=args.run_name,
                       tags=['tree_ring_watermark_generation'])  # Updated tag
            wandb.config.update(args)
            table = wandb.Table(
                columns=['gen_no_w', 'no_w_clip_score', 'gen_w', 'w_clip_score', 'prompt', 'no_w_metric', 'w_metric'])
        except Exception as e:
            print(f"Wandb initialization failed: {e}. Tracking disabled.")
            args.with_tracking = False  # Disable tracking if init fails

    # load diffusion model
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")  # Added device printout

    try:
        scheduler = DPMSolverMultistepScheduler.from_pretrained(args.model_id, subfolder='scheduler', cache_dir=os.getenv('HF_HOME')) # Added cache_dir
        pipe = InversableStableDiffusionPipeline.from_pretrained(
            args.model_id,
            scheduler=scheduler,
            torch_dtype=torch.float16 if device == 'cuda' else torch.float32,  # Use float32 on CPU
            revision='fp16' if device == 'cuda' else None,  # Don't force fp16 on CPU
            safety_checker=None, # Explicitly disable safety checker as per original warning
            cache_dir=os.getenv('HF_HOME'), # Added cache_dir
            # low_cpu_mem_usage=False # Consider adding if memory is an issue, requires accelerate
        )
        # pipe.to(device) # Move pipe to device later if needed, maybe after component loading

        # If using CPU, manually move components if pipe.to(device) wasn't enough or done later
        if device == 'cpu':
             print("Ensuring all model components are on CPU...")
             pipe.vae.to(device)
             pipe.text_encoder.to(device)
             pipe.unet.to(device)
        else:
             pipe.to(device) # If cuda, move the whole pipe

        print("Diffusion pipeline loaded successfully.")
    except Exception as e:
        print(f"Error loading diffusion pipeline: {e}")
        print(
            "Please ensure the model ID is correct, you have internet access (or the model is cached), and necessary dependencies are installed.")
        # Print traceback for more details
        import traceback
        traceback.print_exc()
        return  # Exit if pipeline fails to load

    # reference model (optional, only used for CLIP score calculation)
    ref_model = None
    ref_clip_preprocess = None
    ref_tokenizer = None
    if args.reference_model is not None:
        try:
            print(f"Loading reference model: {args.reference_model}")
            ref_model, _, ref_clip_preprocess = open_clip.create_model_and_transforms(args.reference_model,
                                                                                      pretrained=args.reference_model_pretrain,
                                                                                      device=device,
                                                                                      cache_dir=os.getenv('HF_HOME')) # Added cache_dir
            ref_tokenizer = open_clip.get_tokenizer(args.reference_model)
            print("Reference model loaded.")
        except Exception as e:
            print(f"Could not load reference model: {e}. CLIP scores will be 0.")
            args.reference_model = None  # Disable reference model usage if loading fails

    # dataset - Use default prompt dataset if --dataset is not specified or fails to load
    try:
        # --- Call the modified get_dataset function ---
        dataset, prompt_key = get_dataset(args)
        # --- ---
        print(f"Dataset loaded successfully. Using prompt key: '{prompt_key}'. Number of samples available: {len(dataset)}")
        # Adjust end based on dataset size if needed
        args.end = min(args.end, len(dataset))
        print(f"Will process prompts from index {args.start} to {args.end - 1}.")
    except Exception as e:
        print(f"Error during dataset processing stage: {e}")
        import traceback
        traceback.print_exc()
        return

    tester_prompt = ''  # assume at the detection time, the original prompt is unknown
    try:
        text_embeddings = pipe.get_text_embedding(tester_prompt)
    except Exception as e:
        print(f"Error getting text embedding for tester prompt: {e}")
        import traceback
        traceback.print_exc()
        return

    # ground-truth patch
    try:
        gt_patch = get_watermarking_pattern(pipe, args, device)
    except Exception as e:
        print(f"Error getting watermarking pattern: {e}")
        import traceback
        traceback.print_exc()
        return

    results = []
    clip_scores = []
    clip_scores_w = []
    no_w_metrics = []
    w_metrics = []

    # --- Define the output directory for generated images ---
    output_dir = 'test' # Changed from 'test_img' to 'test' to match original script intention? Or choose a better name like 'generated_images'
    os.makedirs(output_dir, exist_ok=True)
    print(f"Watermarked images will be saved to: {os.path.abspath(output_dir)}")
    # --- ---

    print(f"Starting generation loop from index {args.start} to {args.end - 1}...")
    for i in tqdm(range(args.start, args.end)):
        seed = i + args.gen_seed

        try:
            current_prompt = dataset[i][prompt_key]
            print(f"\nProcessing index {i}, seed {seed}, prompt: '{current_prompt[:100]}...'")  # Print current prompt
        except Exception as e:
            print(f"Error accessing dataset index {i} with key '{prompt_key}': {e}. Skipping.")
            continue  # Skip to next iteration if prompt fails

        # --- Generation without watermarking (still runs but not saved) ---
        # We keep this part as the original script uses the latent for the watermarked version
        try:
            set_random_seed(seed)
            init_latents_no_w = pipe.get_random_latents(height=args.image_length, width=args.image_length) # Pass height/width
            if init_latents_no_w is not None:
                init_latents_no_w = init_latents_no_w.to(device, dtype=pipe.text_encoder.dtype)  # Ensure latents are on the correct device and dtype

            print("Generating non-watermarked image...")
            # Ensure inputs match expected types, especially on CPU
            prompt_embeds = pipe.get_text_embedding(current_prompt).to(device, dtype=pipe.text_encoder.dtype)
            negative_prompt_embeds = pipe.get_text_embedding("").to(device, dtype=pipe.text_encoder.dtype) # Example negative prompt

            outputs_no_w = pipe(
                prompt_embeds=prompt_embeds, # Use embeddings
                # current_prompt, # Original used prompt string
                num_images_per_prompt=args.num_images,
                guidance_scale=args.guidance_scale,
                num_inference_steps=args.num_inference_steps,
                height=args.image_length,
                width=args.image_length,
                latents=init_latents_no_w,
                output_type='pil',  # Ensure PIL output
                # Pass negative embeds if using classifier-free guidance > 1.0
                negative_prompt_embeds=negative_prompt_embeds if args.guidance_scale > 1.0 else None,
            )
            orig_image_no_w = outputs_no_w.images[0]
            print("Non-watermarked image generated.")
        except Exception as e:
            print(f"Error during non-watermarked generation for prompt index {i}: {e}. Skipping.")
            import traceback
            traceback.print_exc()
            continue  # Skip if non-watermarked fails

        # --- Generation with watermarking ---
        try:
            print("Preparing for watermarked generation...")
            if init_latents_no_w is None:
                print("Generating new random latents for watermarked image.")
                set_random_seed(seed)
                init_latents_w = pipe.get_random_latents(height=args.image_length, width=args.image_length) # Pass height/width
            else:
                # print("Reusing latents from non-watermarked generation.") # Can be verbose
                init_latents_w = copy.deepcopy(init_latents_no_w)

            if init_latents_w is not None:
                init_latents_w = init_latents_w.to(device, dtype=pipe.text_encoder.dtype)  # Ensure latents are on the correct device and dtype

            # get watermarking mask
            watermarking_mask = get_watermarking_mask(init_latents_w, args, device)

            # inject watermark
            init_latents_w = inject_watermark(init_latents_w, watermarking_mask, gt_patch, args)
            print("Watermark injected into latents.")

            print("Generating watermarked image...")
            # Reuse embeddings from non-watermarked step
            outputs_w = pipe(
                prompt_embeds=prompt_embeds, # Use embeddings
                # current_prompt,
                num_images_per_prompt=args.num_images,
                guidance_scale=args.guidance_scale,
                num_inference_steps=args.num_inference_steps,
                height=args.image_length,
                width=args.image_length,
                latents=init_latents_w, # Use watermarked latents
                output_type='pil',  # Ensure PIL output
                # Pass negative embeds if using classifier-free guidance > 1.0
                negative_prompt_embeds=negative_prompt_embeds if args.guidance_scale > 1.0 else None,
            )
            orig_image_w = outputs_w.images[0]
            print("Watermarked image generated.")

            # !!! --- Save the watermarked image --- !!!
            filename = f"watermarked_image_{i:04d}_seed{seed}.png"  # Format index with leading zeros
            filepath = os.path.join(output_dir, filename)
            try:
                orig_image_w.save(filepath)
                print(f"Saved watermarked image to: {filepath}")
            except Exception as e:
                print(f"Error saving image {filepath}: {e}")
            # !!! --- Saving code finished --- !!!

        except Exception as e:
            print(
                f"Error during watermarked generation or saving for prompt index {i}: {e}. Skipping evaluation for this item.")
            import traceback
            traceback.print_exc()
            # Skip the rest of the loop (evaluation part) if watermarked generation/saving fails
            if args.with_tracking and table:  # Check if table exists
                table.add_data(None, 0, None, 0, current_prompt, 'Error', 'Error')
            continue

        # --- The rest of the code performs evaluation (CLIP score, watermark detection) ---
        # --- This part will still run but is not strictly necessary for just generating images ---
        # --- You could potentially comment out or remove this section if you ONLY want generation ---
        # --- and want to speed up the process ---
        try:
            print("Starting evaluation steps (distortion, reverse diffusion, metrics)...")
            # distortion
            orig_image_no_w_auged, orig_image_w_auged = image_distortion(orig_image_no_w, orig_image_w, seed, args)

            # reverse img without watermarking
            img_no_w = transform_img(orig_image_no_w_auged).unsqueeze(0).to(text_embeddings.dtype).to(device)
            image_latents_no_w = pipe.get_image_latents(img_no_w, sample=False)

            # Use the same negative embeds as generation
            reversed_latents_no_w = pipe.forward_diffusion(
                latents=image_latents_no_w,
                text_embeddings=negative_prompt_embeds, # Use negative/unconditional embeds for reversal
                guidance_scale=1, # No CFG for reversal
                num_inference_steps=args.test_num_inference_steps,
            )

            # reverse img with watermarking
            img_w = transform_img(orig_image_w_auged).unsqueeze(0).to(text_embeddings.dtype).to(device)
            image_latents_w = pipe.get_image_latents(img_w, sample=False)

            reversed_latents_w = pipe.forward_diffusion(
                latents=image_latents_w,
                text_embeddings=negative_prompt_embeds, # Use negative/unconditional embeds for reversal
                guidance_scale=1, # No CFG for reversal
                num_inference_steps=args.test_num_inference_steps,
            )

            # eval
            no_w_metric, w_metric = eval_watermark(reversed_latents_no_w, reversed_latents_w, watermarking_mask,
                                                   gt_patch, args)
            print(f"Evaluation metrics: no_w={no_w_metric:.4f}, w={w_metric:.4f}")

            if args.reference_model is not None and ref_model is not None:
                print("Calculating CLIP scores...")
                sims = measure_similarity([orig_image_no_w, orig_image_w], current_prompt, ref_model,
                                          ref_clip_preprocess, ref_tokenizer, device)
                w_no_sim = sims[0].item()
                w_sim = sims[1].item()
                print(f"CLIP scores: no_w={w_no_sim:.4f}, w={w_sim:.4f}")
            else:
                w_no_sim = 0
                w_sim = 0

            results.append({
                'no_w_metric': no_w_metric, 'w_metric': w_metric, 'w_no_sim': w_no_sim, 'w_sim': w_sim,
            })

            # Store metrics for final AUC calculation
            no_w_metrics.append(-no_w_metric)  # Negated as roc_curve expects higher scores for positive class
            w_metrics.append(-w_metric)  # Negated as roc_curve expects higher scores for positive class
            clip_scores.append(w_no_sim)
            clip_scores_w.append(w_sim)

            if args.with_tracking and table: # Check if table exists
                if (args.reference_model is not None) and (i < args.max_num_log_image):
                    table.add_data(wandb.Image(orig_image_no_w), w_no_sim, wandb.Image(orig_image_w), w_sim,
                                   current_prompt, no_w_metric, w_metric)
                else:  # Add data without images if ref model not used or max images logged
                    table.add_data(None, w_no_sim, None, w_sim, current_prompt, no_w_metric, w_metric)

        except Exception as e:
            print(f"Error during evaluation for index {i}: {e}. Skipping evaluation metrics for this item.")
            import traceback
            traceback.print_exc()
            # Still add placeholder if tracking enabled and table exists
            if args.with_tracking and table:
                table.add_data(None, 0, None, 0, current_prompt, 'EvalError', 'EvalError')


    # --- Final evaluation summary (AUC, etc.) ---
    # --- This part is also less relevant if you only want generated images ---
    print("\nGeneration loop finished. Calculating final metrics...")
    # Import numpy late if needed for metrics calculation
    try:
        import numpy as np
    except ImportError:
        print("Warning: numpy not found. Final metrics calculation might fail.")
        np = None # Set to None if not found

    if np and len(no_w_metrics) > 0 and len(w_metrics) > 0:  # Ensure we have metrics and numpy to calculate
        preds = no_w_metrics + w_metrics
        t_labels = [0] * len(no_w_metrics) + [1] * len(w_metrics)  # 0 for no watermark, 1 for watermark

        try:
            fpr, tpr, thresholds = metrics.roc_curve(t_labels, preds, pos_label=1)
            auc = metrics.auc(fpr, tpr)
            # Calculate accuracy at the threshold that maximizes it (closest point to (0,1) on ROC curve)
            # or using Youden's J statistic: max(tpr - fpr)
            optimal_idx = np.argmax(tpr - fpr)
            # optimal_threshold = thresholds[optimal_idx] # Threshold not directly used here for standard acc
            acc = metrics.accuracy_score(t_labels, [1 if p >= thresholds[optimal_idx] else 0 for p in
                                                    preds])  # Calculate acc at optimal threshold

            # Calculate TPR at a low FPR (e.g., 1% or 0.1%)
            low_fpr_indices = np.where(fpr <= 0.01)[0]
            if len(low_fpr_indices) > 0:
                low = tpr[low_fpr_indices[-1]]  # TPR at the highest threshold where FPR <= 0.01
            else:
                low = 0.0  # Or handle case where FPR never gets this low

        except Exception as e:
             print(f"Error calculating ROC/AUC metrics: {e}")
             auc = -1.0 # Indicate error
             acc = -1.0
             low = -1.0

        if args.with_tracking and wandb.run: # Check if wandb run active
            wandb.log({'Table': table})  # Log the table data collected during the run
            wandb.log({'final/clip_score_mean': mean(clip_scores) if clip_scores else 0,
                       'final/clip_score_std': stdev(clip_scores) if len(clip_scores) > 1 else 0,
                       'final/w_clip_score_mean': mean(clip_scores_w) if clip_scores_w else 0,
                       'final/w_clip_score_std': stdev(clip_scores_w) if len(clip_scores_w) > 1 else 0,
                       'final/auc': auc,
                       'final/acc': acc,
                       'final/TPR@1%FPR': low})

        print(f'Final Metrics:')
        print(
            f'  CLIP Score Mean (no watermark): {mean(clip_scores):.4f}' if clip_scores else '  CLIP Score Mean (no watermark): N/A')
        print(
            f'  CLIP Score Mean (watermark): {mean(clip_scores_w):.4f}' if clip_scores_w else '  CLIP Score Mean (watermark): N/A')
        print(f'  Detection AUC: {auc:.4f}')
        print(f'  Detection ACC: {acc:.4f}')
        print(f'  Detection TPR@1%FPR: {low:.4f}')
    else:
        print("Not enough data or numpy not available to calculate final AUC/ACC metrics.")

    if args.with_tracking and wandb.run: # Check if wandb run active
        wandb.finish()
    print("Script finished.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='diffusion watermark generation')  # Updated description
    parser.add_argument('--run_name', default='generate_watermarked')  # Default run name changed
    # --- Keep default dataset, user should NOT provide --dataset for default prompts ---
    parser.add_argument('--dataset', default='Gustavosta/Stable-Diffusion-Prompts',
                        help='Dataset path (Hub name or local file like .parquet/.csv)') # Updated help
    parser.add_argument('--start', default=0, type=int, help='Starting index for prompts')
    parser.add_argument('--end', default=10, type=int,
                        help='Ending index for prompts (exclusive)')  # Default changed to 10 for quicker test
    parser.add_argument('--image_length', default=512, type=int)
    parser.add_argument('--model_id', default='stabilityai/stable-diffusion-2-1-base')
    parser.add_argument('--with_tracking', action='store_true', help='Enable WandB tracking')
    parser.add_argument('--num_images', default=1, type=int)
    parser.add_argument('--guidance_scale', default=7.5, type=float)
    parser.add_argument('--num_inference_steps', default=50, type=int)
    # -- test_num_inference_steps might not be relevant if only generating --
    parser.add_argument('--test_num_inference_steps', default=None, type=int,
                        help='Steps for reverse diffusion (eval only)')
    # -- reference model args only needed if calculating CLIP scores --
    parser.add_argument('--reference_model', default=None, help='CLIP model for reference (e.g., ViT-B-32)')
    parser.add_argument('--reference_model_pretrain', default='laion2b_s34b_b79k',
                        help='Pretraining dataset for ref model')
    parser.add_argument('--max_num_log_image', default=10, type=int)  # Reduced default logged images
    parser.add_argument('--gen_seed', default=0, type=int, help='Base seed offset')

    # watermark parameters
    parser.add_argument('--w_seed', default=999999, type=int)
    parser.add_argument('--w_channel', default=0, type=int)
    parser.add_argument('--w_pattern', default='rand')
    parser.add_argument('--w_mask_shape', default='circle')
    parser.add_argument('--w_radius', default=10, type=int)
    parser.add_argument('--w_measurement', default='l1_complex')
    parser.add_argument('--w_injection', default='complex')
    parser.add_argument('--w_pattern_const', default=0, type=float)

    # --- distortion args are only for evaluation, not needed for pure generation ---
    parser.add_argument('--r_degree', default=None, type=float)
    parser.add_argument('--jpeg_ratio', default=None, type=int)
    parser.add_argument('--crop_scale', default=None, type=float)
    parser.add_argument('--crop_ratio', default=None, type=float)
    parser.add_argument('--gaussian_blur_r', default=None, type=int)
    parser.add_argument('--gaussian_std', default=None, type=float)
    parser.add_argument('--brightness_factor', default=None, type=float)
    parser.add_argument('--rand_aug', default=0, type=int)

    args = parser.parse_args()

    # Default test steps to inference steps if not provided (only affects evaluation)
    if args.test_num_inference_steps is None:
        args.test_num_inference_steps = args.num_inference_steps

    # Make sure end is greater than start
    if args.end <= args.start:
        print(
            f"Warning: --end ({args.end}) must be greater than --start ({args.start}). Adjusting --end to {args.start + 1}")
        args.end = args.start + 1

    main(args)