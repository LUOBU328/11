from diffusers import StableDiffusionPipeline, DPMSolverMultistepScheduler
import torch

model_id = 'stabilityai/stable-diffusion-2-1-base'
# 注意：这里使用标准 StableDiffusionPipeline，而不是 Inversable...
try:
    pipe = StableDiffusionPipeline.from_pretrained(
        model_id,
        torch_dtype=torch.float32, # CPU 通常用 float32
        # safety_checker=None # 标准库可能需要 safety_checker，先不禁用试试
    )
    print("Standard StableDiffusionPipeline loaded successfully!")
except Exception as e:
    print(f"Error loading standard pipeline: {e}")